import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class ServicesService {
   domain = "http://localhost:8080/";
  //domain=""
  constructor(
    private http: Http
  ) { }
  getallLona_details(){
    return this.http.get(this.domain +'leading_club/get_loan_details').map(res=>res.json())
  }
}
