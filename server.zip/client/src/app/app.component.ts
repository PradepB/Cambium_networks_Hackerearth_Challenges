import { Component, OnInit } from '@angular/core';
import { ServicesService } from "./services.service"
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  term
  constructor(
    private ServicesService: ServicesService,
    private router:Router) {
  }
  loan_list
  getAllSongs() {
    this.ServicesService.getallLona_details().subscribe(data => {
      this.loan_list = data
    })
  }
  
  ngOnInit() {
    this.getAllSongs()
  }

}
